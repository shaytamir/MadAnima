<?php $__env->startSection('main_content'); ?>
<div class="row">
    <div class="col-md-12">
        <h1><?php echo e($product['title']); ?></h1>
        <p><img width="500" src="<?php echo e(asset('images/products/' .$product['image'])); ?>" alt=""></p>
        <p><?php echo $product['article']; ?></p>
        <p><b>price on site</b><?php echo e($product['price']); ?>$</p>
        <p><?php echo e($product['id']); ?></p>
        <p>
            <?php if( !Cart::get($product['id']) ): ?>
            <input data-id="<?php echo e($product['id']); ?>" class="btn btn-success add_to_cart_btn" type="button"
                id="<?php echo e($product['id']); ?>" value="+ Add to cart">
            <?php else: ?>
            <input class="btn btn-success add_to_cart_btn" type="button" value="in cart" disabled>
            <?php endif; ?>
            <a href="<?php echo e(url('shop/chechout')); ?>" class="btn btn-primary">Checkout</a>
        </p>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Melamed\resources\views/content/product.blade.php ENDPATH**/ ?>