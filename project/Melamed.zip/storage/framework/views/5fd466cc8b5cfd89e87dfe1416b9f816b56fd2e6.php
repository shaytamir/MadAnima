   
   <?php $__env->startSection('cms_content'); ?>
   <div class="row">
       <div class="col-md-12">
           <h1>Edit this product - </h1>
       </div>

   </div>
   <div class="row">
       <div class="col-md-6">
           <form action="<?php echo e(url('cms/products/' . $product['id'])); ?>" method="POST" novalidate
               enctype="multipart/form-data">
               <?php echo e(csrf_field()); ?>

               <?php echo e(method_field('PUT')); ?>

               <input type="hidden" name="item_id" value="<?php echo e($product['id']); ?>">


               <div class="mb-3 form-group">
                   <label for="categorie_id" class="form-label">Category:</label>
                   <select name="categorie_id" id="categorie_id" class="form-control">

                       <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <option <?php if($product['categorie_id']==$item['id'] ): ?> selected="selected" <?php endif; ?>
                           value="<?php echo e($item['id']); ?>">
                           <?php echo e($item['title']); ?></option>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </select>

                   <!-- <span class="text-danger"><?php echo e($errors->first('title')); ?></span> -->
               </div>




               <div class="mb-3">
                   <label for="title" class="form-label">Title</label>
                   <input type="text" name="title" placeholder="Title" value="<?php echo e($product['title']); ?>"
                       class="form-control origin_text" id="title">
               </div>
               <div class="mb-3">
                   <label for="url" class="form-label">Url</label>
                   <input type="text" name="url" placeholder="url" value="<?php echo e($product['url']); ?>"
                       class="form-control target_text" id="url">
               </div>
               <div class="mb-3 form-group">
                   <label for="article" class="form-label">Content:</label>
                   <textarea id="article" name="article" placeholder="Write your content here..."
                       class="form-control"><?php echo e($product['article']); ?></textarea>
               </div>
               <div class="mb-3 form-group">
                   <label for="price" class="form-label">Price:</label>
                   <input type="price" name="price" placeholder="Product Price" value="<?php echo e($product['price']); ?>"
                       class="form-control" id="price">
               </div>

               <div class="mb-3">
                   <img width="80" src="<?php echo e(asset('images/products/' . $product['image'] )); ?>" alt="">
                   <br><br>
                   <label for="image" class="form-label">Change Product Image</label>
                   <input type="file" name="image" id="image">
               </div>




               <a href="<?php echo e(url('cms/products')); ?>" type="button" name="cencel" class="btn btn-secondary">Cencel</a>
               <button type="submit" name="submit" class="btn btn-primary">Save</button>

           </form>
       </div>
   </div>


   <?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Melamed\resources\views/cms/products/edit_product.blade.php ENDPATH**/ ?>