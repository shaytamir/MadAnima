<?php $__env->startSection('main_content'); ?>
<div class="row">
    <div class="col-md-12">
        <h1>About Us MelamedAnimation</h1>
        <p>here bla bla bla </p>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Melamed\resources\views/content/about.blade.php ENDPATH**/ ?>