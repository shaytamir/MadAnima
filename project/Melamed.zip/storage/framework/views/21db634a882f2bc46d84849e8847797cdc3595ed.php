<?php $__env->startSection('main_content'); ?>
<div class="row">
    <div class="col-md-12">
        <h1><?php echo e(str_replace('Melamed |', '', $title)); ?></h1>

    </div>
</div>

<?php if( !empty($products) ): ?>
<div class="row">
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-6">
        <h3><?php echo e($product['title']); ?></h3>
        <p><img src="<?php echo e(asset('images/products/' . $product['image'] )); ?>" width="200"></p>
        <p><?php echo $product['article']; ?></p>
        <p><b>price on site</b><?php echo e($product['price']); ?>$</p>
        <p>
            <?php if( !Cart::get($product['id']) ): ?>
            <input data-id="<?php echo e($product['id']); ?>" class="btn btn-success add_to_cart_btn" type="button"
                id="<?php echo e($product['id']); ?>" value="+ Add to cart">
            <?php else: ?>
            <input class="btn btn-success add_to_cart_btn" type="button" value="in cart" disabled>
            <?php endif; ?>
            <a href="<?php echo e(url('shop/' . $cat_url . '/' . $product['url'])); ?>" class="btn btn-primary">More Details</a>
        </p>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Melamed\resources\views/content/products.blade.php ENDPATH**/ ?>