<?php

$title = 'Melamed | 404 page';
$menu = App\Models\Menu::all()->toArray();

?>

<?php $__env->startSection('main_content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="alert alert-warning" role="alert">
            <h3>OOPS! The Page is not found</h3>
            <p>ERROR 404</p>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Melamed\resources\views/errors/404.blade.php ENDPATH**/ ?>