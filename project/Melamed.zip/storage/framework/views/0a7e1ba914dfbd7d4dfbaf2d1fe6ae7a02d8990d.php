   
   <?php $__env->startSection('cms_content'); ?>
   <div class="row">
       <div class="col-md-12">
           <h1>Add new category - </h1>
       </div>

   </div>
   <div class="row">
       <div class="col-md-6">
           <form action="<?php echo e(url('cms/categories')); ?>" method="POST" novalidate enctype="multipart/form-data">
               <?php echo e(csrf_field()); ?>



               <div class="mb-3">
                   <label for="title" class="form-label">Title</label>
                   <input type="text" name="title" placeholder="Title" value="<?php echo e(old('title')); ?>"
                       class="form-control origin_text" id="title">
               </div>
               <div class="mb-3">
                   <label for="url" class="form-label">Url</label>
                   <input type="text" name="url" placeholder="url" value="<?php echo e(old('url')); ?>"
                       class="form-control target_text" id="url">
               </div>
               <div class="mb-3 form-group">
                   <label for="article" class="form-label">Content:</label>
                   <textarea id="article" name="article" placeholder="Write your content here..."
                       class="form-control"><?php echo e(old('article')); ?></textarea>
               </div>

               <div class="mb-3">
                   <label for="image" class="form-label">Category Image</label>
                   <input type="file" name="image" id="image">
               </div>




               <a href="<?php echo e(url('cms/categories')); ?>" type="button" name="cencel" class="btn btn-secondary">Cencel</a>
               <button type="submit" name="submit" class="btn btn-primary">Save</button>

           </form>
       </div>
   </div>

   <?php $__env->stopSection(); ?>

<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Melamed\resources\views/cms/categories/add_category.blade.php ENDPATH**/ ?>