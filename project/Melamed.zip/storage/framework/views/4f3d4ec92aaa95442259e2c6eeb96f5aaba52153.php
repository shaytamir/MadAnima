<?php $__env->startSection('cms_content'); ?>
<div class="row">
    <div class="col-md-12">
        <h3>Are you sure for deleting this item? </h3>
    </div>

</div>
<div class="row">
    <div class="col-md-6">
        <form action="<?php echo e(url('cms/categories/' . $id)); ?>" method="POST" novalidate>
            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('DELETE')); ?>


            <a href="<?php echo e(url('cms/categories')); ?>" type="button" name="cencel" class="btn btn-secondary">Cencel</a>
            <button type="submit" name="submit" class="btn btn-danger">Delete</button>

        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Melamed\resources\views/cms/categories/delete_category.blade.php ENDPATH**/ ?>