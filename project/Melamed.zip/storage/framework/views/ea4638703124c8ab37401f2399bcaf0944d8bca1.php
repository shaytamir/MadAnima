   
   <?php $__env->startSection('cms_content'); ?>
   <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
       <h1 class="h2">Edit Site Content</h1>



   </div>
   <div class="row">
       <div class="col-md-12">
           <p>
               <a class="btn btn-primary" href="<?php echo e(url('cms/content/create')); ?>">+ Add new content </a>
           </p>

       </div>
   </div>
   <div class="row">
       <div class="col-md-6">
           <table class="table table-border">
               <thead>
                   <tr>
                       <th>Title</th>
                       <th>Updated At</th>
                       <th>Operation</th>
                   </tr>
               </thead>
               <tbody>
                   <?php $__currentLoopData = $content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <tr>
                       <td><?php echo e($item['title']); ?></td>
                       <td><?php echo e($item['updated_at']); ?></td>
                       <td>
                           <a href="<?php echo e(url('cms/content/' . $item['id'] . '/edit')); ?>">Edit</a> |

                           <a href="<?php echo e(url('cms/content/' . $item['id'])); ?>"><img width="12"
                                   src="<?php echo e(url('images/icons/trash-blue.png')); ?>" alt="">
                           </a>

                       </td>
                   </tr>

                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </tbody>
           </table>
       </div>
   </div>

   <?php $__env->stopSection(); ?>

<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Melamed\resources\views/cms/content/content.blade.php ENDPATH**/ ?>