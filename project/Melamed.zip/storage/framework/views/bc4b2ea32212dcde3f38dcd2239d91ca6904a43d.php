<?php $__env->startSection('main_content'); ?>
<div class="row">
    <div class="col-md-12">
        <h1>MelamedAnimation Shop Categories</h1>




    </div>
</div>
<div class="row">

    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-4 col-sm-6">
        <h3><?php echo e($categorie['title']); ?></h3>
        <p class="category_img_p"><img src="<?php echo e(asset('images/categories/' . $categorie['image'])); ?>" alt=""></p>
        <p><?php echo $categorie['article']; ?></p>
        <p>
            <!-- <input type="button" class="btn btn-success" value="+add to cart" /> -->
            <a href="<?php echo e(url('shop/' . $categorie['url'])); ?>" class="btn btn-primary">View Products</a>
        </p>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Melamed\resources\views/content/categories.blade.php ENDPATH**/ ?>