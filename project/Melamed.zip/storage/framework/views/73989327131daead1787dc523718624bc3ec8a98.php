   
   <?php $__env->startSection('cms_content'); ?>
   <div class="row">
       <div class="col-md-12">
           <h1>Edit this content - </h1>
       </div>

   </div>
   <div class="row">
       <div class="col-md-6">
           <form action="<?php echo e(url('cms/content/' . $content['id'])); ?>" method="POST" novalidate>
               <?php echo e(csrf_field()); ?>

               <?php echo e(method_field('PUT')); ?>

               <div class="mb-3 form-group">
                   <label for="menu-link" class="form-label">Menu Link:</label>
                   <select name="menu_id" id="menu-link" class="form-control">

                       <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <option <?php if($content['menu_id']==$item['id'] ): ?> selected="selected" <?php endif; ?>
                           value="<?php echo e($item['id']); ?>">
                           <?php echo e($item['link']); ?></option>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </select>

                   <!-- <span class="text-danger"><?php echo e($errors->first('title')); ?></span> -->
               </div>
               <div class="mb-3 form-group">
                   <label for="title" class="form-label">Title:</label>
                   <input type="text" name="title" placeholder="Title" value="<?php echo e($content['title']); ?>"
                       class="form-control" id="title">
                   <!-- <span class="text-danger"><?php echo e($errors->first('title')); ?></span> -->
               </div>
               <div class="mb-3 form-group">
                   <label for="article" class="form-label">Content:</label>
                   <textarea id="article" name="article" placeholder="Write your content here..."
                       class="form-control"><?php echo e($content['article']); ?></textarea>
                   <!-- <span class="text-danger"><?php echo e($errors->first('article')); ?></span> -->
               </div>




               <a href="<?php echo e(url('cms/content')); ?>" type="button" name="cencel" class="btn btn-secondary">Cencel</a>
               <button type="submit" name="submit" class="btn btn-primary">Update</button>

           </form>
       </div>
   </div>


   <?php $__env->stopSection(); ?>

<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Melamed\resources\views/cms/content/edit_content.blade.php ENDPATH**/ ?>