<!DOCTYPE html>
<html lang="en">

<head>
    <title><?php echo e($title); ?></title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--butstrap 5 | CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <!--butstrap 5 | js only -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.min.js"
        integrity="sha384-nsg8ua9HAw1y0W1btsyWgBklPnCUAFLuTMS2G72MMONqmOymq585AcH49TLBQObG" crossorigin="anonymous">
    </script>

    <!-- ajax \ jquery -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <link rel="stylesheet" href="<?php echo e(asset('/css/app.css')); ?>" type="text/css">
    <!-- favicon -->
    <link rel="icon" href="<?php echo e(asset('favicon.ico')); ?>" type="image/ico" />
    <link rel="shortcut icon" href="<?php echo e(asset('favicon.ico')); ?>" type="image/x-icon" />

    <script>
    const BASE_URL = "<?php echo e(url('')); ?>/"
    </script>

</head>

<body>

    <header>
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('')); ?>">MelamedAnimation</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                    aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" style="justify-content: space-between;" id="navbarNav">
                    <ul class="navbar-nav">
                        <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="nav-item">
                            <a class="nav-link" aria-current="page" href="<?php echo e(url($item['url'])); ?>"><?php echo e($item['link']); ?></a>
                        </li>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <li class="nav-item">
                            <a class="nav-link" aria-current="page" href="<?php echo e(url('shop')); ?>">shop</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active cart_div" aria-current="page" href="<?php echo e(url('shop/checkout')); ?>">
                                <?php if( !Cart::isEmpty() ): ?>
                                <div class="total_cart"><?php echo e(Cart::getTotalQuantity()); ?></div>
                                <?php endif; ?>
                                <img src="<?php echo e(asset('images/icons/grocery-cart-small.png')); ?>" alt="grocery-cart">
                            </a>
                        </li>
                    </ul>
                    <ul class="nav navbar-nav">
                        <?php if( !Session::has('user_id') ): ?>
                        <li class="nav-item">
                            <a class="nav-link " href="<?php echo e(url('user/signin')); ?>">Sign
                                in</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link " href="<?php echo e(url('user/signup')); ?>">Sign
                                up</a>
                        </li>
                        <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('user/profile')); ?>"><?php echo e(Session::get('user_name')); ?></a>
                        </li>

                        <?php if(Session::has('is_admin')): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('cms/dashboard')); ?>">CMS</a>
                        </li>
                        <?php endif; ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('user/logout')); ?>">Logout</a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <br>
    <main>
        <div class="container">
            <!-- show message -->
            <?php if( Session::has('sm')): ?>
            <div class="row sm-box">
                <div class="row">
                    <div class="col-md-12">
                        <div class="alert alert-success">
                            <?php echo e(Session::get('sm')); ?>

                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <!-- error logic -->
            <?php if($errors->any()): ?>
            <div class="row">
                <div class="col-md-12">
                    <br>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <?php echo $__env->yieldContent('main_content'); ?>
        </div>
    </main>
    <br>
    <br>
    <br>
    <footer>
        <div class="container">
            <hr>
            <div class="row">
                <div class="col-md-12">
                    <p class="text-center">Melamed &copy; <?php echo e(date('Y')); ?></p>
                </div>
            </div>
        </div>
    </footer>

    <script src="<?php echo e(asset('js/main.js')); ?>"></script>

</body>





</html><?php /**PATH C:\xampp\htdocs\Melamed\resources\views/master.blade.php ENDPATH**/ ?>