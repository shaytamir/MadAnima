require("./bootstrap");
// $(".add_to_cart_btn").on("click", () => {
//     console.log(213);
// });
