@extends('master')
@section('main_content')
<div class="row">
    <div class="col-md-12">
        <h1>About Us MelamedAnimation</h1>
        <p>here bla bla bla </p>
    </div>
</div>
@endsection
