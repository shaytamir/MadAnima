@extends('master')
@section('main_content')
<div class="row">
    <div class="col-md-12">
        <h1>Welcome to MelamedAnimation</h1>
        <p>your internet </p>
    </div>
</div>
@endsection
